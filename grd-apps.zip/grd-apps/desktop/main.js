const {app,BrowserWindow,Menu}=require("electron");
const URL_APP="https://retraitdp.vercel.app";
function create(){
  const w=new BrowserWindow({width:1280,height:800,title:"GRD BEPC",icon:__dirname+"/icon.ico",autoHideMenuBar:true});
  Menu.setApplicationMenu(null);
  w.webContents.on("did-fail-load",(e,code,desc,url,isMain)=>{
    if(isMain&&code!==-3){
      w.loadURL("data:text/html;charset=utf-8,"+encodeURIComponent("<body style='font-family:sans-serif;padding:24px'><h2>Pas de connexion internet</h2><p>Vérifiez la connexion puis relancez l'application.</p></body>"));
    }
  });
  w.loadURL(URL_APP);
}
app.whenReady().then(create);
app.on("window-all-closed",()=>app.quit());
